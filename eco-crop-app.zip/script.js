// Language translations
document.getElementById("advisorForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const soil = document.getElementById("soilType").value.toLowerCase();
  const season = document.getElementById("season").value.toLowerCase();
  const ph = parseFloat(document.getElementById("phLevel").value);

  const crops = getCrops(soil, season, ph);
  const tips = getTips(soil, season, ph);
  const fertilizers = getOrganicSuggestions(soil);

  document.getElementById("cropSelectionBox").innerHTML = `<h3>Recommended Crops:</h3><ul>${crops.map(crop => `<li>${crop}</li>`).join('')}</ul>`;
  document.getElementById("cultivationTips").innerHTML = `<h3>Cultivation Tips:</h3><p>${tips}</p>`;
  document.getElementById("suggestionBox").innerHTML = `<h3>Organic Manure Suggestions:</h3><p>${fertilizers}</p>`;
});

function getCrops(soil, season, ph) {
  const cropDatabase = {
    sandy: { summer: ["Groundnut", "Watermelon"], monsoon: ["Maize"], winter: ["Wheat"] },
    loamy: { summer: ["Cotton"], monsoon: ["Paddy"], winter: ["Wheat", "Barley"] },
    clayey: { monsoon: ["Rice"], winter: ["Mustard"] },
    silty: { monsoon: ["Jute", "Paddy"], winter: ["Wheat"] },
    chalky: { summer: ["Barley"], autumn: ["Oats"] },
    peaty: { winter: ["Potatoes"] },
    red: { summer: ["Millet"], monsoon: ["Sorghum"] },
    black: { monsoon: ["Cotton", "Soybean"] },
    laterite: { monsoon: ["Tea", "Coffee"] }
  };

  if (cropDatabase[soil] && cropDatabase[soil][season]) {
    return cropDatabase[soil][season].filter(crop => (ph >= 5.5 && ph <= 8));
  } else {
    return ["No suitable crops found for the given inputs."];
  }
}

function getTips(soil, season, ph) {
  return `Ensure proper irrigation for ${soil} soil in ${season}. Maintain pH around ${ph.toFixed(1)}. Use mulching to retain soil moisture and control weeds.`;
}

function getOrganicSuggestions(soil) {
  return `Use compost, farmyard manure (FYM), and green manures like sunhemp. For ${soil} soil, vermicompost and biofertilizers are especially effective without harming the environment.`;
}
